console.log(("xyz">10)?"Apple":"Mango"); //Mango //M
console.log(("xyz">=20)?"Apple":"Mango"); //Mango //A
console.log(("xyz"<15)?"Apple":"Mango"); //Mango //M
console.log(("xyz"<=25)?"Apple":"Mango"); //Mango //A
console.log(("xyz"==50)?"Apple":"Mango"); //Mango //M
console.log(("xyz"===10)?"Apple":"Mango"); //Mango //M
console.log(("xyz"!=15)?"Apple":"Mango"); //Apple //A
console.log(("xyz"!==10)?"Apple":"Mango"); //Apple //A
console.log((10>5 && 15>10)?"Orange":"Blue"); //Orange //O
console.log((10<5 && 15>10)?"Orange":"Mango"); //Mango //B
console.log((20>20 && 30<30)?"Orange":"Blue"); //Blue //B
console.log((20>=20 && 30<=20)?"Orange":"Blue"); //Blue //B
console.log((20==20 && 30==30)?"Orange":"Blue"); //Orange //O
console.log((25==20 && 30==30)?"orange":"Blue"); //Blue //B
console.log((25!=20 && 30!=30)?"Orange":"Blue"); //Blue //B
console.log((55!=55 && 30!=30)?"Orange":"Blue"); //Blue //B
console.log((25!==20 && 30!==30)?"Orange":"Blue"); //Blue //O
console.log((45!==45 && 30!==30)?"Orange":"Blue"); //Blue //B
console.log((20>"10" && 30>"20")?"Orange":"Blue"); //Orange //B
console.log((20>"10" && 30<"20")?"Orange":"Blue"); //Blue //O
console.log((20>="20" && 30<="30")?"Orange":"Blue"); //Orange //O
console.log(("20">="20" && "30"<="30")?"Orange":"Blue"); //Orange //O
console.log(("20">="10" && "10"<="30")?"Orange":"Blue"); //Orange //O
console.log(("20">="10" && "10"<="30")?"Orange":"Blue"); //Orange //O
console.log((100=="100" && 80=="80")?"BMW":"Swift"); //BMW //B
console.log(("100"=="100" && "80"=="80")?"BMW":"Swift"); //BMW //B
console.log((60!="60" && "80"!="80")?"BMW":"Swift"); //Swift //S
console.log((60!="100" && "80"!="80")?"BMW":"Swift"); //Swift //S
console.log((60!="60" && 50!="80")?"BMW":"Swift"); //Swift //S
console.log((60!=="60" && "80"!=="80")?"BMW":"Swift"); //Swift //S
console.log((60!=="100" && "80"!=="80")?"BMW":"Swift"); //Swift //S
console.log((60!=="60" && 50!=="80")?"BMW":"Swift"); //BMW //S
console.log(("aaa"=="aaa" && "bbb"=="bbb")?"Honda":"TVS"); //Honda //H
console.log(("aa"=="aaa" && "bbb"=="bbb")?"Honda":"TVS"); //TVS //T
console.log(("aa"=="caa" && "bbb"=="bbb")?"Honda":"TVS"); //TVS //T
console.log(("aa"=="aa" && "bbb"=="bb")?"Honda":"TVS"); //TVS //T
console.log(("aaa"!="aaa" && "bbb"!="bb")?"Honda":"TVS") //TVS //T
console.log(("baa"!="aa" && "bbb"!="bb")?"Honda":"TVS") //Honda //T
console.log(("aaa"!=="aaa" && "bbb"!=="bb")?"Honda":"TVS") //TVS //T
console.log(("baa"!=="aa" && "bbb"!=="bab")?"Honda":"TVS") //Honda //T
console.log((10>5 || 15>10)?"Orange":"Blue"); //Orange //O
console.log((10<5 || 15>10)?"Orange":"Blue") //Orange //O
console.log((20>20 || 30<30)?"Orange":"Blue") //Blue //B
console.log((20>=20 || 30<=20)?"Orange":"Blue") //Orange //O
console.log((20==20 || 30==30)?"Orange":"Blue") //Orange //O
console.log((25==20 || 30==30)?"Orange":"Blue") //Orange //O
console.log((25!=20 || 30!=30)?"Orange":"Blue") //Orange //O
console.log((55!=55 || 30!=30)?"Orange":"Blue") //Blue //B
console.log((25!==20 || 30!==30)?"Orange":"Blue") //Orange //B
console.log((45!==45 || 30!==30)?"Orange":"Blue") //Blue //B
console.log((20>"10" || 30>"20")?"Orange":"Blue") //Orange //O
console.log((20>"10" || 30<"20")?"Orange":"Blue") //Orange //O
console.log((20>="20" || 30<="30")?"Orange":"Blue") //Orange //O
console.log(("20">="20" || "30"<="30")?"Orange":"Blue") //Orange //O
console.log(("20">="10" || "10"<="30")?"Orange":"Blue") //Orange //O
console.log(("20">="10" || "10"<="30")?"Orange":"Blue") //Orange //O
console.log((100=="100" || 80=="80")? "BMW":"Swift"); //BMW //B
console.log(("100"=="100" || "80"=="80")?"BMW":"Swift"); //BMW //B
console.log((60!="60" || "80"!="80")?"BMW":"SWift"); //Swift //S
console.log((60!="100" || "80"!="80")? "BMW" : "Swift"); //BMW //S
console.log((60!="60" || 50!="80")?"BMW":"Swift"); //BMW //B
console.log((60!=="60" || "80"!=="80")? "BMW": "Swift"); //BMW //B
console.log((60!=="100" || "80"!==80)? "BMW":"Swift"); //BMW //B
console.log((60!=="60" || 50!=="80")? "BMW" : "Swift"); //BMW //B
console.log(("aaa"== "aaa" || "bbb")? "Honda" : "TVS"); //Honda //H
console.log(("aa"=="aaa" || "bbb"=="bbb")?"Honda":"TVS"); //Honda //H
console.log(("aa"=="caa" || "bbb"=="bbb")?"Honda":"TVS"); //Honda //H
console.log(("aa"=="aa" || "bbb"=="bb")?"Honda":"TVS"); //Honda ///H
console.log(("aaa"!="aaa" || "bbb"!="bb")?"Honda":"TVS"); //Honda //H
console.log(("baa"!="aa" || "bbb"!="bab")?"Honda":"TVS"); //Honda //H
console.log(("aaa"!=="aaa" && "bbb"!=="bb")?"Honda":"TVS"); //TVS //H  //71-59 = 12
console.log(("baa"!=="aa" && "bbb"!=="bab")?"Honda":"TVS"); //Honda  //H ---paper turn over---
console.log("hi"<"hello" && "hello"<"hi");  //False //F
console.log("hi">"hello" && "hello"<"hi"); //True  //F
console.log("hi"<"hi" && "hello" < "hello"); //False  //F
console.log("hi">"hi" && "hello" > "hi");//False //F
console.log("a"<"abc" && "abc" < "adb"); //True //F
console.log("b">"abc" && "abc" < "adb"); //True //F
console.log("a" < "abc" && "abc"<"adb"); //True //F
console.log("a">"abc" && "abc"<"adb"); //False //F
console.log("a">"abc" && "abc">"adb"); //False //F
console.log("a"<"a" && "a"<"a"); //False //F
console.log("abc"<"abc" && "abc" < "abc"); //False //F
console.log("a"<"abc" && "a"<"abc"); //True //F
console.log("a">"abc" && "a">"abc"); // False //F
console.log("a"<= "abc" && "abc"<="a") //False //T
console.log("a"<= "abc" && "abc">="a") //True //T
console.log("a"<= "abc" && "abc"<="a") //False //T
console.log("a">= "abc" && "abc">="a") //False //T
console.log("abc"!="abc" && "abc"=="abc") //False  //T
console.log("abc" != "abc" && "abc" != "abc") //False //F
console.log("abc" !== "abc" && "abc" !== "abc") //False //F
console.log("hello" < "world" && "hello" < "world"); //True //F
console.log("hello" < "world" && "hello" > "world"); //False //F
console.log("hello" > "world" && "hello" < "world"); //False //F
console.log("hello" > "world" && "hello" > "world"); //False //F
console.log("hello" < "heat" && "hello" < "heat"); //False //F
console.log("world" < "heat" && "world" < "world"); //False //F
console.log("heat" <= "hello" && "hello" <= "heat"); //False //T
console.log("heat" <= "hello" && "heat" >= "world"); //False //T
console.log("hello" >= "heat" && "hello" <= "heat"); //False //T
console.log("hello" >= "heat" && "hello" >= "heat"); //True //T
console.log("heat" <= "hello" && "hello" <= "heat"); //False //T
console.log("hello" >= "hello" && "world" >= "world"); //True //T
console.log("hello" == "heat" && "hello" == "heat"); //False //F
console.log("hello" === "world" && "hello" === "world"); //False //F 35-21 = 14
console.log("hello"=="heat" && "world"=="heat"); //False //F
console.log("hello"=="world" && "hello"=="hello");//False //T
console.log("world" == "world" && "world" == "world");//True //T
console.log("mango"<"orange" || "mango"<"orange");//True //F
console.log("mango"<"orange" || "mango">"orange");//True //F
console.log("mango">"orange" || "mango"<"orange");//True //F
console.log("mango">"orange"||"mango">"orange");//False //F
console.log("madhavi"<="madhuri" || "madhavi"<="madhuri");//True //F
console.log("madhavi"<="madhuri"||"madhavi">="madhuri")//True //F
console.log("madhavi">="madhuri" || "madhavi"<="madhuri")//True //F
console.log("madhavi">="madhuri" || "madhavi">="madhuri")//False //F
console.log("madhavi"=="madhuri" || "madhuri"=="madhuri")//True //T
console.log("madhavi"=="madhuri" || "madhuri"==="madhuri")//True //T
console.log("madhavi"=="madhavi" || "madhavi"=="madhavi")//True //T
console.log("madhavi"==="madhavi" || "madhuri"==="madhuri")//True //T
console.log("manjula"<"mani" || "manjula"<"mani");//False //F
console.log("manjula"<"mani" || "manjula">"mani");//True //F
console.log("manjula">"mani" || "manjula"<"mani");//True //F
console.log("manjula">"mani" || "manjula">"mani");//True //F
console.log("mani"==="mani" || "manjula"==="mani");//True //T
console.log("pune"<="punjab" || "pune"<="punjab");//True //T
console.log("pune"<="punjab" || "pune">="punjab");//True //T
console.log("pune">="punjab" || "pune"<="punjab");//True //T
console.log("pune">="punjab" || "pune">="punjab");//False //T
console.log("pune"=="pune" || "punjab"=="punjab");//True //T
console.log("punjab"=="punjab" || "pune"=="pune");//True //T
console.log("pune"=="pune" || "pune"=="pune");//True //T
console.log("punjab"=="punjab" || "punjab"=="punjab");//True //T
console.log("punjab"=="pune" || "pune"==="punjab");//False //F
console.log("punjab"==="pune" || "pune"=="punjab");//False //F
console.log("pune"<="punjab" || "punjab"=="pune");//True //F
console.log("pune"<="pune"||"punjab"=="punjab"); //True //T
console.log("pune"<="punjab"||"Punjab"!="pune"); //True //T
console.log("pune"=="punjab"||"punjab"!="pune"); //True //T 34-22=12